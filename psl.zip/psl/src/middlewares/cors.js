const cors = require('cors');

module.exports = (app) => {
    const corsOptions = {
        origin: "http://localhost:3000",
    credentials: true,
        methods: ['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS']
    };

    app.use(cors(corsOptions));
}