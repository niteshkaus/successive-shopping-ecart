const bodyParser = require('body-parser');
const cors = require('./cors');
import cookieParser from 'cookie-parser';

module.exports = (app) => {

    app.use(bodyParser.json({ limit: '20mb' }));
    app.use(cookieParser());
    cors(app);

    app.use((req, res, next) => {
       
        next();
    });
}
