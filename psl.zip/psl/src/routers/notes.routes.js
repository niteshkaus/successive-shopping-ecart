import express from 'express';
const passport = require('passport');
import notesController from '../controller/notes.controller';
const passportJWT = passport.authenticate('jwt', { session: false });

const router = express.Router();

router.get("/",passportJWT, notesController.get);

module.exports = router;
