const express = require('express');
const UsersController  = require('../controller/users.controller');
const passport = require('passport');
const { validateBody, schemas } = require('../helpers/route.helper');
const passportSignIn = passport.authenticate('local', { session: false });
const passportJWT = passport.authenticate('jwt', { session: false });
const passportConf = require('../passport');

const router = express.Router();

router.route('/signup')
  .post(validateBody(schemas.authSchema), UsersController.signUp);

router.route('/signin')
  .post(validateBody(schemas.authSchema), passportSignIn, UsersController.signIn);

router.get('/signout', passportJWT, UsersController.signOut);

router.post('/google-signin', passport.authenticate('googleToken', { session: false }), UsersController.googleOAuth);
router.post('/google-signout', passportJWT, UsersController.unlinkGoogle);

module.exports = router;