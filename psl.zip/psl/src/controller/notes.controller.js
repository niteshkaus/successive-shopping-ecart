import Notes from '../model/notes.model';
import { Types } from 'mongoose';
const ObjectId = Types.ObjectId;

/**
 * Return list of notes and list of notes on the notes id basis
 *
 * @param {*} req
 * @param {*} res
 */
const get = async (req, res) => {
  const { id } = req.query;
  if (id && !ObjectId.isValid(id)) {
    return res
      .status(400)
      .send({ status: "failure", errors: "The notes id is invalid" });
  }

  const cond = {};
  if (id && id.length) cond._id = id;
  const result = await Notes.find(cond);
  res.status(200).send({ status: "success", data: result });
};

module.exports = {
  get
};
