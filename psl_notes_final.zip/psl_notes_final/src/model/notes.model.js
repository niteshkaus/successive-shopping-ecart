import mongoose, { Schema } from 'mongoose';

const notesSchema = new Schema({
  title: {
    type: String,
    required: [true, 'Notes title is required.'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Notes Description is required.'],
    trim: true
  },
}, 
{
  timestamps: true
});

notesSchema.methods = {
  toJSON() {
    return {
      id: this._id,
      title: this.title,
      description: this.description
    };
  }
};

module.exports = mongoose.model('notes', notesSchema);