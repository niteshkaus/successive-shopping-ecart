const helper = require('../helpers/helper');
const User = require('../model/user.model');
const sessionHelper = require('../helpers/session.helper');
const JWT_SECRET= 'pslnotesauthentication';
const JWT = require('jsonwebtoken');

const signToken = user => {
    return JWT.sign({
        iss: 'CodeWorkr',
        sub: user.id,
        iat: new Date().getTime(), // current time
        exp: new Date().setDate(new Date().getDate() + 1) // current time + 1 day ahead
    }, JWT_SECRET);
}


const googleOAuth = async (req, res, next) => {
    // Generate token
    const token = signToken(req.user);
    res.cookie('access_token', token, {
        httpOnly: true
    });
    res.status(200).json({ success: true });
}



module.exports = {
    googleOAuth
}