import swaggerJsdoc from 'swagger-jsdoc';
import dotenv from 'dotenv';

dotenv.config();
const options = {
    swaggerDefinition: {
      info: {
        title: 'Persistent Systems Limited - Notes Management',
        version: '1.0.0',
        description: 'All v1 routes documentation',
      },
      host: `${process.env.BASE_URL}`,
      basePath: '/api/v1/', 
      security: [
        {
          "basicAuth": []
        }
      ]
    },
    // List of files to be processes. You can also set globs './routes/*.js'
    apis: ['./src/routers/*.js'],
  };
  module.exports = options;

  