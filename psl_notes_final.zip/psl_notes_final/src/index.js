/* eslint-disable no-console */
import express from 'express';
import dotenv from 'dotenv';
import routes from './routers';
import middlewares from './middlewares';
import connectDb from './config/database';
// initialise environment
dotenv.config();


let app = new express();
middlewares(app);
routes(app);

connectDb()
  .then(async () => {
    console.log("db conected!!");
    /**
     * start server
     */

    // eslint-disable-next-line no-unused-vars
    let port = process.env.PORT || 5000;
    const server = await app.listen(port, err => {
      if (err) {
        console.log("Failed to start server", err.message);
        // eslint-disable-next-line no-undef
        process.exit(0);
      }

      console.log(`Server is running on port ${port}!`);
    });
  })
  .catch(error => {
    console.log("Failed to connect mongo server", error.message);
  });
