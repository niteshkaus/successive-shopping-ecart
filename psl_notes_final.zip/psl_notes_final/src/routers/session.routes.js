const express = require('express');
const UsersController  = require('../controller/users.controller');
const passport = require('passport');
const passportConf = require('../passport');

const router = express.Router();



router.post('/oauth/google', passport.authenticate('googleToken', { session: false }), UsersController.googleOAuth);


module.exports = router;