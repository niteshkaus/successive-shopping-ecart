import express from 'express';
import notesController from '../controller/notes.controller';

const router = express.Router();

router.get("/", notesController.get);

module.exports = router;
